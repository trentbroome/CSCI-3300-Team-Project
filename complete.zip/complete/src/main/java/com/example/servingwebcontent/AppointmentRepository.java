package com.example.servingwebcontent;


import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

public interface AppointmentRepository extends CrudRepository<Appointment, Integer> {

    @Query(value = "SELECT * FROM appointment WHERE checked_in = 1", nativeQuery = true)
    public Iterable<Appointment> getCheckedInAppointments();

}
