package com.example.servingwebcontent;

import javax.persistence.*;

import com.example.servingwebcontent.model.DBFile;
 
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @Column(name = "order_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String modality;
    private String notes;
    private Integer status;
    private String report;
    @Column(name = "patient_id")
    private Integer patientId;
    private String Tech;
    private String Radio;
    private Integer appointmentId;
    @Transient
    Patient patientObject;
    @Transient
    Appointment appointmentObject;
    @Transient
    private Iterable<Patient> lastName;
    @Transient
    private Iterable<Appointment> appttime;
    @Transient
    private Iterable<DBFile> fileList;

    public Iterable<DBFile> getFileList(){
        return this.fileList;
    }

    public void setFileList(Iterable<DBFile> fileList){
        this.fileList = fileList;
    }

    
    public Integer getAppointmentId(){
        return this.appointmentId;
    }
    
    public void setAppointmentId(Integer appointmentId)
    {
        this.appointmentId = appointmentId;
    }
    
    public Integer getPatientId(){
        return this.patientId;
    }

    public void setPatient_id(Integer patientId){
        this.patientId = patientId;
    }
    public Iterable<Appointment> appttime()
    {
        return this.appttime;
    }

    public void setappttime(Iterable<Appointment> appttime)
    {
        this.appttime = appttime;
    }
    public Iterable<Patient> getLastName()
    {
        return this.lastName;
    }

    public void setLastName(Iterable<Patient> lastName)
    {
        this.lastName = lastName;
    }

    public Long getId(){
        return this.id;
    }
    
    public String getModality(){
        return this.modality;
    }
    public String getNotes(){
        return this.notes;
    }
    public Integer getStatus(){
        return this.status;
    }
    public String getReport(){
        return this.report;
    }
    public Patient getPatientObject(){
        return this.patientObject;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setModality(String modality){
        this.modality = modality;
    }
    

    public void setNotes(String notes){
        this.notes = notes;
    }

    public void setStatus(Integer status){
        this.status = status;
    }

    public void setReport(String report){
        this.report = report;
    }

    public void setPatientObject(Patient patientObject){
        this.patientObject = patientObject;
    }
    public String getTech(){
        return this.Tech;
    }
    public void setTech(String Tech){
        this.Tech = Tech;
    }
    public String getRadio(){
        return this.Radio;
    }
    
    public void setRadio(String Radio){
        this.Radio = Radio;
    }
}