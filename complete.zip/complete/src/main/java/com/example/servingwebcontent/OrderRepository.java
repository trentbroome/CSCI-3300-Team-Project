package com.example.servingwebcontent;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
 
public interface OrderRepository extends CrudRepository<Order, Long> {
    @Query(value = "SELECT * FROM orders WHERE patient_id = ?1", nativeQuery = true)
    public Iterable<Order> getAllFilesByOrderId(Integer patient);

    @Query(value = "SELECT * FROM orders WHERE status = ?1", nativeQuery = true)
    public Iterable<Order> getAllOrdersByStatus(Integer status);
}