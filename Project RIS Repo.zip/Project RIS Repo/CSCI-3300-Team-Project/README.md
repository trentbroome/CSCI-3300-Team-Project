# CSCI-3300-Team-Project

Team Project for CSCI 3300 where we developed a functioning RIS Webapp
