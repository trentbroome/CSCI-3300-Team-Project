package com.example.accessingdatamysql;

import org.springframework.data.repository.CrudRepository;




public interface CompletedtaskRepository extends CrudRepository<Completedtask, Integer> {
    
}
