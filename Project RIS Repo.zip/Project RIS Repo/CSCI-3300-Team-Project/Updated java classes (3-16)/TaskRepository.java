package com.example.accessingdatamysql;

import org.springframework.data.repository.CrudRepository;




public interface TaskRepository extends CrudRepository<Task, Integer> {

}