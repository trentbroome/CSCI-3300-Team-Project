package com.example.servingwebcontent;

import org.springframework.data.repository.CrudRepository;
 
public interface ModalityRepository extends CrudRepository<Modality, Long> {
 
}