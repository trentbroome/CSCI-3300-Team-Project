package com.example.servingwebcontent;

import javax.persistence.*;
 
@Entity
@Table(name = "orders")
public class Order {
    @Id
    @Column(name = "order_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long patient;
    private String modality;
    private String notes;
    private Long status;
    private Long report;
    private Integer patient_id;
    @Transient
    Patient patientObject;
    @Transient
    private Iterable<Patient> lastName;
    public Integer getPatient_id(){
        return this.patient_id;
    }

    public void setPatient_id(Integer patient_id){
        this.patient_id = patient_id;
    }
    public Iterable<Patient> getLastName()
    {
        return this.lastName;
    }

    public void setLastName(Iterable<Patient> lastName)
    {
        this.lastName = lastName;
    }

    public Long getId(){
        return this.id;
    }
    public Long getPatient(){
        return this.patient;
    }
    
    public String getModality(){
        return this.modality;
    }
    public String getNotes(){
        return this.notes;
    }
    public Long getStatus(){
        return this.status;
    }
    public Long getReport(){
        return this.report;
    }
    public Patient getPatientObject(){
        return this.patientObject;
    }

    public void setId(Long id){
        this.id = id;
    }

    public void setPatient(Long patient){
        this.patient = patient;
    }

    public void setModality(String modality){
        this.modality = modality;
    }
    

    public void setNotes(String notes){
        this.notes = notes;
    }

    public void setStatus(Long status){
        this.status = status;
    }

    public void setReport(Long report){
        this.report = report;
    }

    public void setPatientObject(Patient patientObject){
        this.patientObject = patientObject;
    }
}