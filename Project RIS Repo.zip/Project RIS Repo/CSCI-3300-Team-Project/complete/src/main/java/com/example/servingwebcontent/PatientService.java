package com.example.servingwebcontent;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

public class PatientService {
    @Autowired
    private PatientRepository repo;
     
}
