package com.example.servingwebcontent;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity // This tells Hibernate to make a table out of this class
@Table(name = "appointment") //This specifies the primary table for the annotated entity in MySQL. MAKE SURE YOUR NAMES MATCH IN YOUR SQL 

public class Appointment {
    @Id //Specifies the primary key of an entity.
    @Column(name = "appointment_id") //Specifies the mapped column for a persistent property or field.
    @GeneratedValue(strategy=GenerationType.AUTO) //The GeneratedValue annotation may be applied to a primary key property or field of an entity or mapped superclass in conjunction with the Id annotation
    private Integer id;
    private String appttime;
    private String Tech;
    private String Radio;
    private Integer order_id;
    @Transient
    Patient patientObject;
    public Integer getOrder_Id() {
        return order_id;
    }

    public void setOrder_Id(Integer order_id) {
        this.order_id = order_id;
    }
    public Integer getId(){
        return this.id;
    }
    public void setId(Integer id)
    {
        this.id = id;
    }
    public String getAppttime(){
        return this.appttime;
    }
    public void setAppttime(String appttime)
    {
        this.appttime = appttime;
    }
    public String getTech(){
        return this.Tech;
    }
    public void setTech(String Tech){
        this.Tech = Tech;
    }
    public String getRadio(){
        return this.Radio;
    }
    
    public void setRadio(String Radio){
        this.Radio = Radio;
    }
    public Patient getPatient(){
        return this.patientObject;
    }
    public void setPatientObject(Patient patientObject){
        this.patientObject = patientObject;
    }

}