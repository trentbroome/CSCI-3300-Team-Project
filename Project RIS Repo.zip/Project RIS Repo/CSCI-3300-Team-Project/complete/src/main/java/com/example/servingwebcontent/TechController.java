package com.example.servingwebcontent;

import org.apache.tomcat.util.http.fileupload.FileUpload;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

public class TechController 
{
    
}